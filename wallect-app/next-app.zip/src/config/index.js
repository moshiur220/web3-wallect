import { defaultWagmiConfig } from "@web3modal/wagmi/react/config";
import { authConnector } from "@web3modal/wagmi";

import { cookieStorage, createStorage } from "wagmi";
import { mainnet, arbitrum, base, sepolia } from "wagmi/chains";

// Get projectId from https://cloud.walletconnect.com
export const projectId = "6b633f37cf5d3b13261f9420b524a946";

if (!projectId) throw new Error("Project ID is not defined");

export const metadata = {
  name: "appkit-app",
  description: "Wallet Connect App",
  url: "https://web3modal.com", // origin must match your domain & subdomain
  icons: ["https://avatars.githubusercontent.com/u/37784886"]
};

// Create wagmiConfig
const chains = [mainnet, arbitrum, base, sepolia];
export const config = defaultWagmiConfig({
  chains,
  projectId,
  metadata,
  auth: {
    email: true, // default to true
    socials: ["github", "google", "x", "discord", "apple"],
    showWallets: true, // default to true
    walletFeatures: true // default to true
  },
  ssr: true,
  storage: createStorage({
    storage: cookieStorage
  })
});